function localConstructor(key) {
  // just to have some type of datastore
  if(!window.__local__){
    window.__local__ = {};
  }

  this.support = ("localStorage" in window) ? true : false,
  this.setter = function(key, obj){
    return (this.support) ? localStorage.setItem(key, obj) : __local__[key] = obj;
  };
  this.getter = function(key){
    if(this.support) {
      return localStorage.getItem(key);
    }else{ 
      return __local__[key];
    }
  };
  this.key = key;
  this.write = function (key, obj) {
    if(this.key){
      obj = key;
      key = this.key;
    }
    this.setter(key, JSON.stringify(obj));
    return this;
  };

  this.get = function (key) {

    if(this.key){
      key = this.key;
    }

    var obj = this.getter(key);

    if(typeof obj === "string"){
      obj = JSON.parse(obj);
    }

    return obj;
  };

  this.clear = function () {
    if(this.key){
      this.remove();
    }else{
      localStorage.clear();
    }

    return this;
  };

  this.remove = function (key) {
    if(this.key){
      key = this.key;
    }
    if(this.support){
      localStorage.removeItem(key);
    }else{
      // set value to null
      this.setter(key, null);
    }
    return this;
  };
}

local = new localConstructor();


var profilepopout = function () {
   $('.profile').each(function () {
       var repin_img = $(this).find("img").attr("src"), new_repin_img;
       $(this).append('<span class="story_popout_hidden" style="display:none;">' + repin_img + '</span>');
       if ($(this).is(':contains("cloudfront")')) {
           new_repin_img = repin_img.replace(".jpg", "_o.jpg");
       } else if ($(this).is(':contains("facebook")')) {
           new_repin_img = repin_img.replace("square", "large");
       } else if ($(this).is(':contains("avatars")')) {
           new_repin_img = repin_img.replace(".jpg", "_o.jpg");
       } else {
           new_repin_img = repin_img.replace("75x75", "192x");
       }
       $(this).after('<div class="story_popout"><div id="pointer"></div><img class="story_popout_image" src="' + new_repin_img + '"></div>');
   });
}; 

if (local.get('pie_settings') == undefined) {
  var obj = {};
  obj.width = 400;
  obj.name = 'four_hundred';
  local.write('pie_settings', obj);
}

var settings_content = '<header>' +
    '<div class="pie_logo"></div>' +
    '<span class="pie_header">Pinterest Image Expander settings</span>' +
    '<div class="close_pie_settings"></div>' +
  '</header>' +
  '<section class="settings_content">' +
    '<header>When hovering over images in Pinterest, how large do you want them to be?</header>' +
    '<div class="three_hundred">' +
      '<span settings_name="three_hundred">300 Pixels</span>' +
    '</div>' +
    '<div class="four_hundred">' +
      '<span settings_name="four_hundred">400 Pixels</span>' +
    '</div>' +
    '<div class="five_hundred">' +
      '<span settings_name="five_hundred">500 Pixels<span class="not_recommended">Not Recommended</span></span>' +
    '</div>' +
  '</section>';

$('.rightHeaderContent').prepend('<span class="pie_setting_gear"></span>');

$('body').append('<div class="pie_white_overlay"></div>');
$('body').append('<div class="pie_settings">' + settings_content + '</div>');

$('div.' + local.get('pie_settings').name + ' > span').addClass('selected');

function settingsConstructor () {
  var overlay = $('.pie_white_overlay');
  var container = $('.pie_settings');

  this.open = function () {
    overlay.fadeIn();
    setTimeout(function () {
      container.fadeIn();
    }, 500);
  }

  this.close = function () {
    container.fadeOut();
    setTimeout(function () {
      overlay.fadeOut();
    }, 500);
  }

  this.change = function (name) {
    var obj = {};
    obj.name = name;
    switch (name) {
      case ('three_hundred'):
        obj.width = 300;
        break;
      case ('four_hundred'):
        obj.width = 400;
        break;
      case ('five_hundred'):
        obj.width = 500;
        break;
    }
    local.write('pie_settings', obj);
  }
}
var settings = new settingsConstructor();

$('body').on('click', '.pie_setting_gear', function () {
  settings.open();
});

$('body').on('click', '.pie_white_overlay, .close_pie_settings', function () {
  settings.close();
});

$('body').on('click', '.pie_settings section div > span', function () {
  $('span.selected').removeClass('selected');
  var span = $(this);
  var name = span.attr('settings_name');
  span.addClass('selected');
  settings.change(name);
});

var profilepopouthide = function () {
   $('.profile').each(function () {
       $('.story_popout').remove();
       $('.story_popout_hidden').remove();
   });
};

$('.feed').bind('mouseover', function () {
   profilepopout();
});

$('.feed').bind('mouseout', function () {
   profilepopouthide();
});

$('.repins ul li a').each(function () {
   var repin_img = $(this).find("img").attr("src"), new_repin_img;
   $(this).append('<span class="story_popout_hidden" style="display:none;">' + repin_img + '</span>');
   if ($(this).is(':contains("cloudfront")')) {
       new_repin_img = repin_img.replace(".jpg", "_o.jpg");
   } else if ($(this).is(':contains("facebook")')) {
       new_repin_img = repin_img.replace("square", "large");
   } else if ($(this).is(':contains("avatars")')) {
       new_repin_img = repin_img.replace(".jpg", "_o.jpg");
   } else {
       new_repin_img = repin_img.replace("75x75", "192x");
   }
   $(this).after('<div class="story_popout"><div id="pointer"></div><img class="story_popout_image" src="' + new_repin_img + '"></div>');
});

var pinLoad = function () {
  $('.PinImageImg:not(.replaced)').each(function () {
    var pin = $(this);
    pin.addClass('replaced');
    var swapImage = pin.attr("src");
    var newImage = swapImage.replace("192x","550x");
    pin.attr("src", newImage); 
  });
  $('.pinImg:not(.replaced)').each(function () {
    var pin = $(this),
        swapImage = pin.attr("src");
    if (swapImage.indexOf('whiteTransparent') == -1) {
      if (swapImage.indexOf('192x') > -1) {
        var newImage = swapImage.replace("192x","550x");
      } else {
        var newImage = swapImage.replace("236x","736x");
      }
      setTimeout(function () {
        pin.attr("src", newImage).addClass('replaced');
      }, 500);
    }
  });
};

pinLoad(); 

$('#ColumnContainer').on('mouseover', '.PinHolder', function () {
   var this_pin = $(this), 
       this_height;
   if (this_pin.hasClass('viewed')) {
       this_height = this_pin.attr('original_height');
   } else {
       this_height = $('.PinImageImg', this_pin).height();
       this_pin.addClass('viewed');
   }
   this_pin.attr('original_height', this_height);
   var new_height = (this_height / 192) * local.get('pie_settings').width;
   this_pin.parent().addClass('hovered');
   $(this).find('.PinImageImg').addClass("expanded_" + local.get('pie_settings').name).attr('width', '').attr('height','').attr('style', "height: " + new_height + "px;");
});

$('#ColumnContainer').on('mouseout', '.PinHolder', function () { 
   var this_pin = $(this);
   var expanded_height = $('.PinImageImg', this_pin).height();
   var reverted_height = this_pin.attr('original_height');
   this_pin.find('.PinImageImg').removeClass("expanded_" + local.get('pie_settings').name+"").attr('style', 'height: ' + reverted_height + 'px');
   $('.pin').each(function(){
       $(this).removeClass('hovered');
   });
});

$('body').on('mouseover', '.pinHolder', function () {
   var this_pin = $(this), 
       this_height,
       original_width,
       new_height;
   if (this_pin.hasClass('viewed')) {
       this_height = this_pin.attr('original_height');
       original_width = this_pin.attr('original_width');
   } else {
       this_height = $('.pinImg', this_pin).height();
       this_pin.addClass('viewed').attr('original_height', this_height);
       original_width = $('.pinImg', this_pin).innerWidth();
       this_pin.attr('original_width', original_width);
   }
   new_height = (this_height / original_width) * local.get('pie_settings').width;
   $('.pinImg', this_pin).addClass("expanded_" + local.get('pie_settings').name).attr('width', '').attr('height','').attr('style', "height: " + new_height + "px;");
});

$('body').on('mouseout', '.pinHolder', function () { 
   var this_pin = $(this);
   var expanded_height = $('.pinImg', this_pin).height();
   var reverted_height = this_pin.attr('original_height');
   var reverted_width = this_pin.attr('original_width');
   this_pin.find('.pinImg').removeClass("expanded_" + local.get('pie_settings').name+"").attr('style', 'height: ' + reverted_height + 'px; width: ' + reverted_width + 'px');
   $('.pin').each(function(){
       $(this).removeClass('hovered');
   });
});

$('#NewIndicator').click(function(){ pinLoad(); });

setInterval(function () {
    pinLoad();
}, 3000);










